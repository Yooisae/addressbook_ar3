from .AddressBook import main

main()